export class Links {
    id: number;
    name: string;
    url: string;

    constructor() {
        this.id = 1;
        this.name = 'added bookmark to google';
        this.url = 'http://www.google.com';
    }
}