import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Links } from '../models/links';
// Import the bookmark service here

@Component({
  selector: 'app-bookmarks',
  imports: [RouterLink, CommonModule],
  templateUrl: './bookmarks.component.html',
  styleUrl: './bookmarks.component.css'
})

export class BookmarksComponent {
  bookmarkList: Links[] = [];

  // Inject the Bookmark service into the constructor below
  constructor() { }

  ngOnInit(): void {
    // Invoke getBookmarks() from the Bookmark service, and set its return value to bookmarkList
  }

  clearBookmarks(): void {
    // Invoke clearBookmarks() from the Bookmark service below

    // Then, clear the local bookmarkList array

    alert("Cleared!");
  }
}
