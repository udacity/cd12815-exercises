import { Routes } from '@angular/router';
import { BookmarksComponent } from './bookmarks/bookmarks.component';
import { DirectoryComponent } from './directory/directory.component';

export const routes: Routes = [  
    { path: '', component: DirectoryComponent },
    { path: 'bookmarks', component: BookmarksComponent },
];
