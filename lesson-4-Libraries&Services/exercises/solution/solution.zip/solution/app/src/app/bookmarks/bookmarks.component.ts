import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Links } from '../models/links';
import { BookmarkService } from '../bookmark.service';
// Import the bookmark service here

@Component({
  selector: 'app-bookmarks',
  imports: [RouterLink, CommonModule],
  templateUrl: './bookmarks.component.html',
  styleUrl: './bookmarks.component.css'
})

export class BookmarksComponent {
  bookmarkList: Links[] = [];

  // Inject the Bookmark service into the constructor below
  constructor(private bookmarkService: BookmarkService) { }

  ngOnInit(): void {
    // Invoke getBookmarks() from the Bookmark service, and set its return value to bookmarkList
    this.bookmarkList=this.bookmarkService.getBookmarks();
  }

  clearBookmarks(): void {
    // Invoke clearBookmarks() from the Bookmark service below
    this.bookmarkService.clearBookmarks();
    // Then, clear the local bookmarkList array
    this.bookmarkList=[];
    alert("Cleared!");
  }
}
