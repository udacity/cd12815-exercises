import { Component } from '@angular/core';
import { LinkService } from '../link.service';
import { RouterLink } from '@angular/router';
import { Links } from '../models/links';
import { CommonModule } from '@angular/common';
import { BookmarkService } from '../bookmark.service';

@Component({
  selector: 'app-directory',
  imports: [RouterLink, CommonModule],
  templateUrl: './directory.component.html',
  styleUrl: './directory.component.css'
})
export class DirectoryComponent {
  linkList: Links[] = [];

  // Inject your Bookmark service into the constructor below
  constructor(private linkService: LinkService, private bookmarkService: BookmarkService) { }

  ngOnInit(): void {
    this.linkList = this.linkService.getLinks();
  }

  addToBookmarks(bookmark: any): void {
    // Invoke addToBookmarks() from the Bookmark service below
    this.bookmarkService.addToBookmarks(bookmark);
    alert("Added!");
  }
}
