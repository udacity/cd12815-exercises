export class zoo {
    id: number;
    name: string;
    fed: boolean;

    constructor() {
      this.id = 1;
      this.name = '';
      this.fed = true;
    }
  }