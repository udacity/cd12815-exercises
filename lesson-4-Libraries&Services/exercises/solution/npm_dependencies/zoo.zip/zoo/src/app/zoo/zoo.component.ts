import { CommonModule } from '@angular/common';
import { Component, Output, EventEmitter } from '@angular/core';
import { zoo } from '../models/zoo';
import { ZooAnimalComponent } from "../zoo-animal/zoo-animal.component";
import { ZooService } from '../services/zoo.service';

@Component({
  selector: 'app-zoo',
  imports: [CommonModule, ZooAnimalComponent],
  templateUrl: './zoo.component.html',
  styleUrl: './zoo.component.css'
})
export class ZooComponent {

  animalList: zoo[] = [];

  constructor(private zooService: ZooService) {}

  ngOnInit(): void {
    this.animalList = this.zooService.getAnimals();
}

onLike(animal: any): void {
  window.alert('I like the '+ animal);
}

}