import { Component } from '@angular/core';
import { ZooComponent } from './zoo/zoo.component';
import { FlexLayoutModule } from "@ngbracket/ngx-layout";

@Component({
  selector: 'app-root',
  imports: [ZooComponent, FlexLayoutModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title: string = "zoo";
}
